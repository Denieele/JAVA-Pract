module order.main {
    requires order.model;
    requires order.processing;
    requires order.storage;
    requires javafaker;
    requires java.sql;
}