package duikt.java.com;

class InvalidInputException extends Exception {
    public InvalidInputException(String message) {
        super(message);
    }
}
