module order.processing {
    requires order.model;
    exports com.example.order.processing;
}