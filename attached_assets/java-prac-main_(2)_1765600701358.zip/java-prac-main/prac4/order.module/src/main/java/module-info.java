module order.model {
    requires static lombok;
    exports com.example.order.model;
}